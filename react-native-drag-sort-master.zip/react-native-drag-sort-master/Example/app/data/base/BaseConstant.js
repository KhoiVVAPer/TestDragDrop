export const TEST_DATA = [
    {icon: require('../../data/img/animal1.png'),txt: 1},
    {icon: require('../../data/img/animal2.png'),txt: 2},
    {icon: require('../../data/img/animal3.png'),txt: 3},
    {icon: require('../../data/img/animal4.png'),txt: 4},
    {icon: require('../../data/img/animal5.png'),txt: 5},
    {icon: require('../../data/img/animal6.png'),txt: 6},
    {icon: require('../../data/img/animal7.png'),txt: 7},
    {icon: require('../../data/img/animal8.png'),txt: 8},
    {icon: require('../../data/img/animal9.png'),txt: 9},
    {icon: require('../../data/img/animal10.png'),txt: 10},
    {icon: require('../../data/img/animal11.png'),txt: 11},
    {icon: require('../../data/img/animal12.png'),txt: 12},
    {icon: require('../../data/img/animal13.png'),txt: 13},
    {icon: require('../../data/img/animal14.png'),txt: 14},
    {icon: require('../../data/img/animal15.png'),txt: 15},
    {icon: require('../../data/img/animal16.png'),txt: 16},
    {icon: require('../../data/img/animal17.png'),txt: 17},
    {icon: require('../../data/img/animal18.png'),txt: 18},
]

export const AUTO_TEST_DATA = [
    {icon: require('../../data/img/animal1.png'),txt: 1},
    {icon: require('../../data/img/animal2.png'),txt: 2},
    {icon: require('../../data/img/animal3.png'),txt: 3},
    {icon: require('../../data/img/animal4.png'),txt: 4},
    {icon: require('../../data/img/animal5.png'),txt: 5},
    {icon: require('../../data/img/animal6.png'),txt: 6},
    {icon: require('../../data/img/animal7.png'),txt: 7},
    {icon: require('../../data/img/animal8.png'),txt: 8},
    {icon: require('../../data/img/animal9.png'),txt: 9},
    {icon: require('../../data/img/animal10.png'),txt: 10},
    {icon: require('../../data/img/animal11.png'),txt: 11},
    {icon: require('../../data/img/animal12.png'),txt: 12},
    {icon: require('../../data/img/animal13.png'),txt: 13},
    {icon: require('../../data/img/animal14.png'),txt: 14},
    {icon: require('../../data/img/animal15.png'),txt: 15},
    {icon: require('../../data/img/animal16.png'),txt: 16},
    {icon: require('../../data/img/animal17.png'),txt: 17},
    {icon: require('../../data/img/animal18.png'),txt: 18},
    {icon: require('../../data/img/animal1.png'),txt: 19},
    {icon: require('../../data/img/animal2.png'),txt: 20},
    {icon: require('../../data/img/animal3.png'),txt: 21},
    {icon: require('../../data/img/animal4.png'),txt: 22},
    {icon: require('../../data/img/animal5.png'),txt: 23},
    {icon: require('../../data/img/animal6.png'),txt: 24},
    {icon: require('../../data/img/animal7.png'),txt: 25},
    {icon: require('../../data/img/animal8.png'),txt: 26},
]

export const TXT = "Never give up, Never lose hope. \n" +
    "\n" +
    "Always have faith, It allows you to cope. \n" +
    "\n" +
    "Trying times will pass, As they always do. \n" +
    "\n" +
    "Just have patience, Your dreams will come true. \n" +
    "\n" +
    "So put on a smile, You'll live through your pain. \n" +
    "\n" +
    "Know it will pass, And strength you will gain."